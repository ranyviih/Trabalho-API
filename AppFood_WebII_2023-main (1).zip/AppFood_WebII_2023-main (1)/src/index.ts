// Importa os módulos necessários
import path from 'node:path'; // path para manipulação de caminhos de arquivos
import express from 'express'; // Express para criar aplicativos web
import mongoose from 'mongoose'; // Mongoose para interagir com o Mongoose

import { router } from './router'; // Importa o arquivo de rotas definido em './router'

// Conecta-se ao banco de dados MongoDB no endereço 'mongodb://localhost:27017'
mongoose.connect('mongodb://localhost:27017')
  .then(() => {
    // Cria uma instância do aplicativo Express
    const app = express();
    const port = 3000; // Define a porta em que o servidor vai receber

    // Configura o middleware para servir arquivos estáticos da pasta '/uploads'
    app.use('/uploads', express.static(path.resolve(__dirname, '..', 'uploads')));

    // Configura o middleware para analisar o corpo das solicitações no formato JSON
    app.use(express.json());

    // Configura o middleware de roteamento usando as rotas definidas em './router'
    app.use(router);

    // Inicia o servidor Express para escutar na porta definida
    app.listen(port, () => {
      console.log(`🚗Server is running on http://localhost:${port}`);
    });
  })
  .catch(() => console.log('Erro ao conectar no MongoDB')); // Manipula erros na conexão com o Mongoose
