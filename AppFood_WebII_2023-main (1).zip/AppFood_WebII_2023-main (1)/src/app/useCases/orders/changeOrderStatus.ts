// Importa os objetos 'Request' e 'Response' da biblioteca 'express'
import { Request, Response } from 'express';

// Importa o modelo de dados 'Order' do arquivo '../../models/Order'
import { Order } from '../../models/Order';

// Define uma função assíncrona chamada 'changeOrderStatus' que recebe uma solicitação (req) e uma resposta (res)
export async function changeOrderStatus(req: Request, res: Response) {
  try {
    // Desestrutura o parâmetro de rota 'orderId' da solicitação (req.params)
    const { orderId } = req.params;

    // Desestrutura o campo 'status' do corpo da solicitação (req.body)
    const { status } = req.body;

    // Verifica se o valor do campo 'status' está entre as opções permitidas
    if (!['WAITING', 'IN_PRODUCTION', 'DONE'].includes(status)) {
      // Se o status não for válido, responde com um status 400 (Bad Request) e uma mensagem de erro
      return res.status(400).json({
        error: 'Status should be one of these: WAITING, IN_PRODUCTION, DONE'
      });
    }

    // Atualiza o status do pedido no banco de dados usando 'Order.findByIdAndUpdate'
    await Order.findByIdAndUpdate(orderId, { status });

    // Responde à solicitação com um status 204 (No Content) para indicar que o status do pedido foi alterado com sucesso
    res.sendStatus(204);
  } catch (error) {
    // Em caso de erro, registra o erro no console e envia um status 500 (Internal Server Error) como resposta
    console.log(error);
    res.sendStatus(500);
  }
}
