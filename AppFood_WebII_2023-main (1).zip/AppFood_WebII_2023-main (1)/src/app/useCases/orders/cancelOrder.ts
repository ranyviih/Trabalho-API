// Importa os objetos 'Request' e 'Response' da biblioteca 'express'
import { Request, Response } from 'express';

// Importa o modelo de dados 'Order' do arquivo '../../models/Order'
import { Order } from '../../models/Order';

// Define uma função assíncrona chamada 'cancelOrder' que recebe uma solicitação (req) e uma resposta (res)
export async function cancelOrder(req: Request, res: Response) {
  try {
    // Desestrutura o parâmetro de rota 'orderId' da solicitação (req.params)
    const { orderId } = req.params;

    // Busca e exclui o pedido com base no ID fornecido usando 'Order.findByIdAndDelete'
    await Order.findByIdAndDelete(orderId);

    // Responde à solicitação com um status 204 (No Content) para indicar que o pedido foi cancelado com sucesso
    res.sendStatus(204);
  } catch (error) {
    // Em caso de erro, registra o erro no console e envia um status 500 (Internal Server Error) como resposta
    console.log(error);
    res.sendStatus(500);
  }
}
