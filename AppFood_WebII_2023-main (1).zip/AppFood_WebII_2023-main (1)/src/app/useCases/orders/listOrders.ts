// Importa os objetos 'Request' e 'Response' da biblioteca 'express'
import { Request, Response } from 'express';

// Importa o modelo de dados 'Order' do arquivo '../../models/Order'
import { Order } from '../../models/Order';

// Define uma função assíncrona chamada 'listOrders' que recebe uma solicitação (req) e uma resposta (res)
export async function listOrders(req: Request, res: Response) {
  try {

    // Consulta todos os pedidos no banco de dados
    const orders = await Order.find()  //O método 'find' retorna todos os documentos da coleção 'Order'
      .sort({ createdAt: 1 }) //O método 'sort' ordena os resultados pelo campo 'createdAt' em ordem crescente 
      .populate('products.product'); //O método 'populate' popula o campo 'products.product', referenciando documentos na coleção 'Product'

    // Responde à solicitação com um JSON contendo a lista de pedidos
    res.json(orders);
  } catch (error) {
    // Em caso de erro, registra o erro no console e envia um status 500 (Internal Server Error) como resposta
    console.log(error);
    res.sendStatus(500);
  }
}
