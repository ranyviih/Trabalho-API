// Importa os objetos 'Request' e 'Response' da biblioteca 'express'
import { Request, Response } from 'express';

// Importa o modelo de dados 'Order' do arquivo '../../models/Order'
import { Order } from '../../models/Order';

// Define uma função assíncrona chamada 'createOrder' que recebe uma solicitação (req) e uma resposta (res)
export async function createOrder(req: Request, res: Response) {
  try {
    // Desestrutura os campos 'table' e 'products' do corpo da solicitação (req.body)
    const { table, products } = req.body;

    // Cria uma nova instância de pedido usando o modelo 'Order' e os campos desestruturados
    const order = await Order.create({ table, products });

    // Responde à solicitação com um status 201 (Created) e envia o pedido criado como resposta em formato JSON
    res.status(201).json(order);
  } catch (error) {
    // Em caso de erro, registra o erro no console e envia um status 500 (Internal Server Error) como resposta
    console.log(error);
    res.sendStatus(500);
  }
}
