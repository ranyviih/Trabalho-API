// Importa os objetos 'Request' e 'Response' da biblioteca 'express'
import { Request, Response } from 'express';

// Importa o modelo de dados 'Product' do arquivo '../../models/Product'
import { Product } from '../../models/Product';

// Define uma função assíncrona chamada 'listProducts' que recebe uma solicitação (req) e uma resposta (res)
export async function listProducts(req: Request, res: Response) {
  try {
    // Consulta todos os produtos no banco de dados usando o modelo 'Product'
    const products = await Product.find();

    // Responde à solicitação com um JSON contendo a lista de produtos
    res.json(products);
  } catch (error) {
    // Em caso de erro, registra o erro no console e envia um status 500 (Internal Server Error) como resposta
    console.log(error);
    res.sendStatus(500);
  }
}
