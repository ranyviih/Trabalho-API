// Importa os objetos 'Request' e 'Response' da biblioteca 'express'
import { Request, Response } from 'express';

// Importa o modelo de dados 'Product' do arquivo '../../models/Product'
import { Product } from '../../models/Product';

// Define uma função assíncrona chamada 'createProduct' que recebe uma solicitação (req) e uma resposta (res)
export async function createProduct(req: Request, res: Response) {
  try {
    // Obtém o nome do arquivo de imagem do produto, se disponível (req.file.filename)
    const imagePath = req.file?.filename;

    // Desestrutura os campos 'name', 'description', 'price', 'category' e 'ingredients' do corpo da solicitação (req.body)
    const { name, description, price, category, ingredients } = req.body;

    // Cria uma nova instância de produto usando o modelo 'Product' e os campos desestruturados
    const product = await Product.create({
      name,
      description,
      imagePath,
      price: Number(price), // Converte para um número
      category,
      ingredients: ingredients ? JSON.parse(ingredients) : [], // Converte a lista de ingredientes em um array se estiver presente
    });

    // Responde à solicitação com um status 201 (Created) e envia o produto criado como resposta em formato JSON
    res.status(201).json(product);
  } catch (error) {
    // Em caso de erro, registra o erro no console e envia um status 500 (Internal Server Error) como resposta
    console.log(error);
    res.sendStatus(500);
  }
}
