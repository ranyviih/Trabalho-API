// Importa os objetos 'Request' e 'Response' da biblioteca 'express'
import { Request, Response } from 'express';

// Importa o modelo de dados 'Category' do arquivo '../../models/Category'
import { Category } from '../../models/Category';

// Define uma função assíncrona chamada 'listCategories' que recebe uma solicitação (req) e uma resposta (res)
export async function listCategories(req: Request, res: Response) {
  try {
    // Consulta todas as categorias no banco de dados usando o método 'find' do modelo 'Category'
    const categories = await Category.find();

    // Responde à solicitação com um JSON contendo a lista de categorias
    res.json(categories);
  } catch (error) {
    // Em caso de erro, registra o erro no console e envia um status 500 (Internal Server Error) como resposta
    console.log(error);
    res.sendStatus(500);
  }
}
