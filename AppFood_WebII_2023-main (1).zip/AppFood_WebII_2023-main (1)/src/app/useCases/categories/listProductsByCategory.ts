// Importa os objetos 'Request' e 'Response' da biblioteca 'express'
import { Request, Response } from 'express';

// Importa o modelo de dados 'Product' do arquivo '../../models/Product'
import { Product } from '../../models/Product';

// Define uma função assíncrona chamada 'listProductsByCategory' que recebe uma solicitação (req) e uma resposta (res)
export async function listProductsByCategory(req: Request, res: Response) {
  try {
    // Desestrutura o parâmetro de rota 'categoryId' da solicitação (req.params)
    const { categoryId } = req.params;

    // Consulta produtos no banco de dados onde o campo 'category' é igual ao 'categoryId'
    const products = await Product.find().where('category').equals(categoryId);

    // Responde à solicitação com um JSON contendo a lista de produtos da categoria especificada
    res.json(products);
  } catch (error) {
    // Em caso de erro, registra o erro no console e envia um status 500 (Internal Server Error) como resposta
    console.log(error);
    res.sendStatus(500);
  }
}
