// Importa os objetos 'Request' e 'Response' da biblioteca 'express'
import { Request, Response } from 'express';

// Importa o modelo de dados 'Category' do arquivo '../../models/Category'
import { Category } from '../../models/Category';

// Define uma função assíncrona chamada 'createCategory' que recebe uma solicitação (req) e uma resposta (res)
export async function createCategory(req: Request, res: Response) {
  try {

    // Desestrutura os campos 'icon' e 'name' do corpo (body) da solicitação (req)
    const { icon, name } = req.body;

    // Cria uma nova instância da categoria utilizando o modelo 'Category' e os campos desestruturados
    const category = await Category.create({ icon, name });

    // Define o status da resposta como 201 (Created) e envia a categoria criada como resposta em formato JSON
    res.status(201).json(category);
  } catch (error) {
    
    // Em caso de erro, registra o erro no console e envia um status 500 (Internal Server Error) como resposta
    console.log(error);
    res.sendStatus(500);
  }
}
