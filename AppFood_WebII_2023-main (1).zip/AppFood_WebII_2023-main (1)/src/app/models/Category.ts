// Importa o 'model' e 'Schema' da biblioteca 'mongoose'
import { model, Schema } from 'mongoose';

// Define o modelo de dados 'Category' utilizando 'model'
export const Category = model('Category', new Schema({
  // Define o campo 'name' e 'icon' como uma string obrigatória 
  name: {
    type: String,
    required: true,
  },
  icon: {
    type: String,
    required: true,
  }
}));
