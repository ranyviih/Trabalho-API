// Importa o 'model' e 'Schema' da biblioteca 'mongoose'
import { model, Schema } from 'mongoose';

// Define o modelo de dados 'Order' utilizando 'model'
export const Order = model('Order', new Schema({

  // Define o campo 'table' como uma string obrigatória 
  table: {
    type: String,
    required: true,
  },

  // Define o campo 'status' como uma string com valores restritos 
  status: {
    type: String,
    enum: ['WAITING', 'IN_PRODUCTION', 'DONE'],
    default: 'WAITING',
  },

  // Define o campo 'createdAt' como uma data com o valor padrão definido como a data atual
  createdAt: {
    type: Date,
    default: Date.now,
  },
  
  // Define o campo 'products' como um array obrigatório de objetos,
  products: {
    required: true,
    type: [{
      // O campo 'product' é um ID de um documento da coleção 'Product' referenciado pelo Mongoose
      product: {
        type: Schema.Types.ObjectId,
        required: true,
        ref: 'Product',
      },
      // O campo 'quantity' é um número com um valor padrão de 1
      quantity: {
        type: Number,
        default: 1,
      },
    }],
  },
}));
