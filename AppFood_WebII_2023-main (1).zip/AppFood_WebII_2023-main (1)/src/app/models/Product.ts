// Importa o 'model' e 'Schema' da biblioteca 'mongoose'
import { model, Schema } from 'mongoose';

// Define o modelo de dados 'Product' utilizando 'model'
export const Product = model('Product', new Schema({
  // Define o campo 'name', 'description' e 'imagePath' como uma string obrigatória
  name: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  imagePath: {
    type: String,
    required: true,
  },
  // Define o campo 'price' como um número obrigatório
  price: {
    type: Number,
    required: true,
  },

  // Define o campo 'ingredients' como um array obrigatório de objetos
  ingredients: {
    required: true,
    type: [{
      // O campo 'name' e 'icon' é uma string obrigatória 
      name: {
        type: String,
        required: true,
      },
      icon: {
        type: String,
        required: true,
      },
    }],
  },
  // Define o campo 'category' como um ID de um documento da coleção 'Category' referenciado pelo Mongoose
  category: {
    type: Schema.Types.ObjectId,
    required: true,
    ref: 'Category',
  },
}));
